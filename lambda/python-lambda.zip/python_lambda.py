import json
from datetime import datetime


def lambda_handler(event, context):
    print("Incoming event:", json.dumps(event))

    # queryStringParameters can be null in API Gateway proxy events.
    query_params = event.get("queryStringParameters") or {}
    name = query_params.get("name", "Unknown")

    response = {
        "message": f"Hello {name} from Python!",
        "timestamp": datetime.utcnow().isoformat(),
    }

    print("Response:", json.dumps(response))

    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(response),
    }
